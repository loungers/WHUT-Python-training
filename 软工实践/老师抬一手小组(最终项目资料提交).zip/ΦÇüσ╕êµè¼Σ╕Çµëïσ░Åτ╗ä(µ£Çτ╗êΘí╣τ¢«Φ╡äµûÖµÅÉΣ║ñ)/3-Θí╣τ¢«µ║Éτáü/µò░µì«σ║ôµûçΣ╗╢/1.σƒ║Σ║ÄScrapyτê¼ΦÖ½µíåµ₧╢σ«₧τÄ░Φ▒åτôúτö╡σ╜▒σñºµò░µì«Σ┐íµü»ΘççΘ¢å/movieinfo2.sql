/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80021
 Source Host           : localhost:3306
 Source Schema         : crawl

 Target Server Type    : MySQL
 Target Server Version : 80021
 File Encoding         : 65001

 Date: 26/07/2020 20:02:26
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for movieinfo
-- ----------------------------
DROP TABLE IF EXISTS `movieinfo`;
CREATE TABLE `movieinfo` (
  `rank` int DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `rating_num` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `comment_num` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `motto` varchar(255) DEFAULT NULL,
  `pic_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of movieinfo
-- ----------------------------
BEGIN;
INSERT INTO `movieinfo` VALUES (1, '肖申克的救赎', '9.7', '2088503人评价', '导演: 弗兰克·德拉邦特 Frank Darabont   主演: 蒂姆·罗宾斯 Tim Robbins /...', '希望让人自由。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p480747492.jpg');
INSERT INTO `movieinfo` VALUES (2, '霸王别姬', '9.6', '1549015人评价', '导演: 陈凯歌 Kaige Chen   主演: 张国荣 Leslie Cheung / 张丰毅 Fengyi Zha...', '风华绝代。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2561716440.jpg');
INSERT INTO `movieinfo` VALUES (3, '阿甘正传', '9.5', '1577453人评价', '导演: 罗伯特·泽米吉斯 Robert Zemeckis   主演: 汤姆·汉克斯 Tom Hanks / ...', '一部美国近现代史。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2372307693.jpg');
INSERT INTO `movieinfo` VALUES (4, '这个杀手不太冷', '9.4', '1767656人评价', '导演: 吕克·贝松 Luc Besson   主演: 让·雷诺 Jean Reno / 娜塔莉·波特曼 ...', '怪蜀黍和小萝莉不得不说的故事。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p511118051.jpg');
INSERT INTO `movieinfo` VALUES (5, '泰坦尼克号', '9.4', '1531033人评价', '导演: 詹姆斯·卡梅隆 James Cameron   主演: 莱昂纳多·迪卡普里奥 Leonardo...', '失去的才是永恒的。 ', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p457760035.jpg');
INSERT INTO `movieinfo` VALUES (6, '美丽人生', '9.5', '987578人评价', '导演: 罗伯托·贝尼尼 Roberto Benigni   主演: 罗伯托·贝尼尼 Roberto Beni...', '最美的谎言。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2578474613.jpg');
INSERT INTO `movieinfo` VALUES (7, '千与千寻', '9.4', '1640417人评价', '导演: 宫崎骏 Hayao Miyazaki   主演: 柊瑠美 Rumi Hîragi / 入野自由 Miy...', '最好的宫崎骏，最好的久石让。 ', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2557573348.jpg');
INSERT INTO `movieinfo` VALUES (8, '辛德勒的名单', '9.5', '803343人评价', '导演: 史蒂文·斯皮尔伯格 Steven Spielberg   主演: 连姆·尼森 Liam Neeson...', '拯救一个人，就是拯救整个世界。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p492406163.jpg');
INSERT INTO `movieinfo` VALUES (9, '盗梦空间', '9.3', '1505755人评价', '导演: 克里斯托弗·诺兰 Christopher Nolan   主演: 莱昂纳多·迪卡普里奥 Le...', '诺兰给了我们一场无法盗取的梦。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p513344864.jpg');
INSERT INTO `movieinfo` VALUES (10, '忠犬八公的故事', '9.4', '1048132人评价', '导演: 莱塞·霍尔斯道姆 Lasse Hallström   主演: 理查·基尔 Richard Ger...', '永远都不能忘记你所爱的人。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p524964039.jpg');
INSERT INTO `movieinfo` VALUES (11, '海上钢琴师', '9.3', '1255994人评价', '导演: 朱塞佩·托纳多雷 Giuseppe Tornatore   主演: 蒂姆·罗斯 Tim Roth / ...', '每个人都要走一条自己坚定了的路，就算是粉身碎骨。 ', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2574551676.jpg');
INSERT INTO `movieinfo` VALUES (12, '楚门的世界', '9.3', '1128803人评价', '导演: 彼得·威尔 Peter Weir   主演: 金·凯瑞 Jim Carrey / 劳拉·琳妮 Lau...', '如果再也不能见到你，祝你早安，午安，晚安。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p479682972.jpg');
INSERT INTO `movieinfo` VALUES (13, '三傻大闹宝莱坞', '9.2', '1398251人评价', '导演: 拉库马·希拉尼 Rajkumar Hirani   主演: 阿米尔·汗 Aamir Khan / 卡...', '英俊版憨豆，高情商版谢耳朵。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p579729551.jpg');
INSERT INTO `movieinfo` VALUES (14, '机器人总动员', '9.3', '990657人评价', '导演: 安德鲁·斯坦顿 Andrew Stanton   主演: 本·贝尔特 Ben Burtt / 艾丽...', '小瓦力，大人生。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1461851991.jpg');
INSERT INTO `movieinfo` VALUES (15, '放牛班的春天', '9.3', '972607人评价', '导演: 克里斯托夫·巴拉蒂 Christophe Barratier   主演: 热拉尔·朱尼奥 Gé...', '天籁一般的童声，是最接近上帝的存在。 ', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1910824951.jpg');
INSERT INTO `movieinfo` VALUES (16, '星际穿越', '9.3', '1130297人评价', '导演: 克里斯托弗·诺兰 Christopher Nolan   主演: 马修·麦康纳 Matthew Mc...', '爱是一种力量，让我们超越时空感知它的存在。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614988097.jpg');
INSERT INTO `movieinfo` VALUES (17, '大话西游之大圣娶亲', '9.2', '1106961人评价', '导演: 刘镇伟 Jeffrey Lau   主演: 周星驰 Stephen Chow / 吴孟达 Man Tat Ng...', '一生所爱。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2455050536.jpg');
INSERT INTO `movieinfo` VALUES (18, '熔炉', '9.3', '681971人评价', '导演: 黄东赫 Dong-hyuk Hwang   主演: 孔侑 Yoo Gong / 郑有美 Yu-mi Jung /...', '我们一路奋战不是为了改变世界，而是为了不让世界改变我们。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1363250216.jpg');
INSERT INTO `movieinfo` VALUES (19, '疯狂动物城', '9.2', '1327972人评价', '导演: 拜伦·霍华德 Byron Howard / 瑞奇·摩尔 Rich Moore   主演: 金妮弗·...', '迪士尼给我们营造的乌托邦就是这样，永远善良勇敢，永远出乎意料。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614500649.jpg');
INSERT INTO `movieinfo` VALUES (20, '无间道', '9.2', '903130人评价', '导演: 刘伟强 / 麦兆辉   主演: 刘德华 / 梁朝伟 / 黄秋生', '香港电影史上永不过时的杰作。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2564556863.jpg');
INSERT INTO `movieinfo` VALUES (21, '龙猫', '9.2', '934338人评价', '导演: 宫崎骏 Hayao Miyazaki   主演: 日高法子 Noriko Hidaka / 坂本千夏 Ch...', '人人心中都有个龙猫，童年就永远不会消失。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2540924496.jpg');
INSERT INTO `movieinfo` VALUES (22, '教父', '9.3', '682407人评价', '导演: 弗朗西斯·福特·科波拉 Francis Ford Coppola   主演: 马龙·白兰度 M...', '千万不要记恨你的对手，这样会让你失去理智。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p616779645.jpg');
INSERT INTO `movieinfo` VALUES (23, '当幸福来敲门', '9.1', '1122231人评价', '导演: 加布里尔·穆奇诺 Gabriele Muccino   主演: 威尔·史密斯 Will Smith ...', '平民励志片。 ', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2614359276.jpg');
INSERT INTO `movieinfo` VALUES (24, '怦然心动', '9.1', '1304241人评价', '导演: 罗伯·莱纳 Rob Reiner   主演: 玛德琳·卡罗尔 Madeline Carroll / 卡...', '真正的幸福是来自内心深处。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p501177648.jpg');
INSERT INTO `movieinfo` VALUES (25, '触不可及', '9.2', '728909人评价', '导演: 奥利维·那卡什 Olivier Nakache / 艾力克·托兰达 Eric Toledano   主...', '满满温情的高雅喜剧。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1454261925.jpg');
INSERT INTO `movieinfo` VALUES (26, '控方证人', '9.6', '297578人评价', '导演: 比利·怀尔德 Billy Wilder   主演: 泰隆·鲍华 Tyrone Power / 玛琳·...', '比利·怀德满分作品。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1505392928.jpg');
INSERT INTO `movieinfo` VALUES (27, '蝙蝠侠：黑暗骑士', '9.2', '753054人评价', '导演: 克里斯托弗·诺兰 Christopher Nolan   主演: 克里斯蒂安·贝尔 Christ...', '无尽的黑暗。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p462657443.jpg');
INSERT INTO `movieinfo` VALUES (28, '活着', '9.2', '585801人评价', '导演: 张艺谋 Yimou Zhang   主演: 葛优 You Ge / 巩俐 Li Gong / 姜武 Wu Jiang', '张艺谋最好的电影。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2513253791.jpg');
INSERT INTO `movieinfo` VALUES (29, '末代皇帝', '9.3', '536542人评价', '导演: 贝纳尔多·贝托鲁奇 Bernardo Bertolucci   主演: 尊龙 John Lone / 陈...', '“不要跟我比惨，我比你更惨”再适合这部电影不过了。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p452089833.jpg');
INSERT INTO `movieinfo` VALUES (30, '寻梦环游记', '9.1', '1112561人评价', '导演: 李·昂克里奇 Lee Unkrich / 阿德里安·莫利纳 Adrian Molina   主演: ...', '死亡不是真的逝去，遗忘才是永恒的消亡。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2614500706.jpg');
INSERT INTO `movieinfo` VALUES (31, '乱世佳人', '9.3', '502148人评价', '导演: 维克多·弗莱明 Victor Fleming / 乔治·库克 George Cukor   主演: 费...', 'Tomorrow is another day.', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1963126880.jpg');
INSERT INTO `movieinfo` VALUES (32, '摔跤吧！爸爸', '9.0', '1147191人评价', '导演: 涅提·蒂瓦里 Nitesh Tiwari   主演: 阿米尔·汗 Aamir Khan / 法缇玛...', '你不是在为你一个人战斗，你要让千千万万的女性看到女生并不是只能相夫教子。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2457983084.jpg');
INSERT INTO `movieinfo` VALUES (33, '何以为家', '9.1', '685523人评价', '导演: 娜丁·拉巴基 Nadine Labaki   主演: 扎因·拉费阿 Zain al-Rafeea / ...', '凝视卑弱生命，用电影改变命运。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2555295759.jpg');
INSERT INTO `movieinfo` VALUES (34, '指环王3：王者无敌', '9.2', '553957人评价', '导演: 彼得·杰克逊 Peter Jackson   主演: 伊利亚·伍德 Elijah Wood / 西恩...', '史诗的终章。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1910825503.jpg');
INSERT INTO `movieinfo` VALUES (35, '少年派的奇幻漂流', '9.1', '1046170人评价', '导演: 李安 Ang Lee   主演: 苏拉·沙玛 Suraj Sharma / 伊尔凡·可汗 Irrfan...', '瑰丽壮观、无人能及的冒险之旅。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1784592701.jpg');
INSERT INTO `movieinfo` VALUES (36, '飞屋环游记', '9.0', '979951人评价', '导演: 彼特·道格特 Pete Docter / 鲍勃·彼德森 Bob Peterson   主演: 爱德...', '最后那些最无聊的事情，才是最值得怀念的。 ', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p485887754.jpg');
INSERT INTO `movieinfo` VALUES (37, '十二怒汉', '9.4', '334290人评价', '导演: Sidney Lumet   主演: 亨利·方达 Henry Fonda / 马丁·鲍尔萨姆 Marti...', '1957年的理想主义。 ', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2173577632.jpg');
INSERT INTO `movieinfo` VALUES (38, '鬼子来了', '9.2', '451124人评价', '导演: 姜文 Wen Jiang   主演: 姜文 Wen Jiang / 香川照之 Teruyuki Kagawa /...', '对敌人的仁慈，就是对自己残忍。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2553104888.jpg');
INSERT INTO `movieinfo` VALUES (39, '素媛', '9.2', '458331人评价', '导演: 李濬益 Jun-ik Lee   主演: 薛景求 Kyung-gu Sol / 严志媛 Ji-won Uhm ...', '受过伤害的人总是笑得最开心，因为他们不愿意让身边的人承受一样的痛苦。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2118532944.jpg');
INSERT INTO `movieinfo` VALUES (40, '天空之城', '9.1', '621421人评价', '导演: 宫崎骏 Hayao Miyazaki   主演: 田中真弓 Mayumi Tanaka / 横泽启子 Ke...', '对天空的追逐，永不停止。 ', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1446261379.jpg');
INSERT INTO `movieinfo` VALUES (41, '哈尔的移动城堡', '9.1', '717055人评价', '导演: 宫崎骏 Hayao Miyazaki   主演: 倍赏千惠子 Chieko Baishô / 木村拓...', '带着心爱的人在天空飞翔。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2174346180.jpg');
INSERT INTO `movieinfo` VALUES (42, '大话西游之月光宝盒', '9.0', '885467人评价', '导演: 刘镇伟 Jeffrey Lau   主演: 周星驰 Stephen Chow / 吴孟达 Man Tat Ng...', '旷古烁今。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2561721372.jpg');
INSERT INTO `movieinfo` VALUES (43, '天堂电影院', '9.2', '483062人评价', '导演: 朱塞佩·托纳多雷 Giuseppe Tornatore   主演: 安东内拉·阿蒂利 Anton...', '那些吻戏，那些青春，都在影院的黑暗里被泪水冲刷得无比清晰。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2559577569.jpg');
INSERT INTO `movieinfo` VALUES (44, '哈利·波特与魔法石', '9.0', '690619人评价', '导演: Chris Columbus   主演: Daniel Radcliffe / Emma Watson / Rupert Grint', '童话世界的开端。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2614949805.jpg');
INSERT INTO `movieinfo` VALUES (45, '罗马假日', '9.0', '717219人评价', '导演: 威廉·惠勒 William Wyler   主演: 奥黛丽·赫本 Audrey Hepburn / 格...', '爱情哪怕只有一天。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2189265085.jpg');
INSERT INTO `movieinfo` VALUES (46, '闻香识女人', '9.1', '624714人评价', '导演: 马丁·布莱斯 Martin Brest   主演: 阿尔·帕西诺 Al Pacino / 克里斯...', '史上最美的探戈。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2550757929.jpg');
INSERT INTO `movieinfo` VALUES (47, '辩护人', '9.2', '448516人评价', '导演: 杨宇硕 Woo-seok Yang   主演: 宋康昊 Kang-ho Song / 金英爱 Yeong-ae...', '电影的现实意义大过电影本身。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2158166535.jpg');
INSERT INTO `movieinfo` VALUES (48, '我不是药神', '9.0', '1532545人评价', '导演: 文牧野 Muye Wen   主演: 徐峥 Zheng Xu / 王传君 Chuanjun Wang / 周...', '对我们国家而言，这样的电影多一部是一部。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2561305376.jpg');
INSERT INTO `movieinfo` VALUES (49, '搏击俱乐部', '9.0', '642241人评价', '导演: 大卫·芬奇 David Fincher   主演: 爱德华·诺顿 Edward Norton / 布拉...', '邪恶与平庸蛰伏于同一个母体，在特定的时间互相对峙。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1910926158.jpg');
INSERT INTO `movieinfo` VALUES (50, '死亡诗社', '9.1', '509469人评价', '导演: 彼得·威尔 Peter Weir   主演: 罗宾·威廉姆斯 Robin Williams / 罗伯...', '当一个死水般的体制内出现一个活跃的变数时，所有的腐臭都站在了光明的对面。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2575465690.jpg');
INSERT INTO `movieinfo` VALUES (51, '教父2', '9.2', '378213人评价', '导演: 弗朗西斯·福特·科波拉 Francis Ford Coppola   主演: 阿尔·帕西诺 A...', '优雅的孤独。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2194138787.jpg');
INSERT INTO `movieinfo` VALUES (52, '狮子王', '9.0', '590016人评价', '导演: Roger Allers / 罗伯·明可夫 Rob Minkoff   主演: 乔纳森·泰勒·托马...', '动物版《哈姆雷特》。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2277799019.jpg');
INSERT INTO `movieinfo` VALUES (53, '指环王2：双塔奇兵', '9.1', '505079人评价', '导演: 彼得·杰克逊 Peter Jackson   主演: 伊利亚·伍德 Elijah Wood / 西恩...', '承前启后的史诗篇章。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p909265336.jpg');
INSERT INTO `movieinfo` VALUES (54, '大闹天宫', '9.3', '284025人评价', '导演: 万籁鸣 Laiming Wan / 唐澄 Cheng Tang   主演: 邱岳峰 Yuefeng Qiu /...', '经典之作，历久弥新。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2184505167.jpg');
INSERT INTO `movieinfo` VALUES (55, '猫鼠游戏', '9.0', '593766人评价', '导演: 史蒂文·斯皮尔伯格 Steven Spielberg   主演: 莱昂纳多·迪卡普里奥 L...', '骗子大师和执著警探的你追我跑故事。 ', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p453924541.jpg');
INSERT INTO `movieinfo` VALUES (56, '窃听风暴', '9.1', '418549人评价', '导演: 弗洛里安·亨克尔·冯·多纳斯马尔克 Florian Henckel von Donnersmarck  &n...', '别样人生。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1808872109.jpg');
INSERT INTO `movieinfo` VALUES (57, '指环王1：魔戒再现', '9.0', '568340人评价', '导演: 彼得·杰克逊 Peter Jackson   主演: 伊利亚·伍德 Elijah Wood / 西恩...', '传说的开始。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1354436051.jpg');
INSERT INTO `movieinfo` VALUES (58, '钢琴家', '9.2', '381269人评价', '导演: 罗曼·波兰斯基 Roman Polanski   主演: 艾德里安·布洛迪 Adrien Brod...', '音乐能化解仇恨。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p792376093.jpg');
INSERT INTO `movieinfo` VALUES (59, '美丽心灵', '9.0', '553004人评价', '导演: 朗·霍华德 Ron Howard   主演: 罗素·克劳 Russell Crowe / 艾德·哈...', '爱是一切逻辑和原由。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1665997400.jpg');
INSERT INTO `movieinfo` VALUES (60, '两杆大烟枪', '9.1', '447460人评价', '导演: Guy Ritchie   主演: Jason Flemyng / Dexter Fletcher / Nick Moran', '4个臭皮匠顶个诸葛亮，盖·里奇果然不是盖的。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p792443418.jpg');
INSERT INTO `movieinfo` VALUES (61, '黑客帝国', '9.0', '571230人评价', '导演: 安迪·沃卓斯基 Andy Wachowski / 拉娜·沃卓斯基 Lana Wachowski   主...', '视觉革命。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p451926968.jpg');
INSERT INTO `movieinfo` VALUES (62, '饮食男女', '9.1', '415666人评价', '导演: 李安 Ang Lee   主演: 郎雄 Sihung Lung / 杨贵媚 Kuei-Mei Yang / 吴...', '人生不能像做菜，把所有的料都准备好了才下锅。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1910899751.jpg');
INSERT INTO `movieinfo` VALUES (63, '飞越疯人院', '9.1', '437476人评价', '导演: 米洛斯·福尔曼 Miloš Forman   主演: 杰克·尼科尔森 Jack Nichols...', '自由万岁。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p792238287.jpg');
INSERT INTO `movieinfo` VALUES (64, '本杰明·巴顿奇事', '8.9', '721559人评价', '导演: 大卫·芬奇 David Fincher   主演: 凯特·布兰切特 Cate Blanchett / ...', '在时间之河里感受溺水之苦。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2192535722.jpg');
INSERT INTO `movieinfo` VALUES (65, 'V字仇杀队', '8.9', '771957人评价', '导演: 詹姆斯·麦克特格 James McTeigue   主演: 娜塔莉·波特曼 Natalie Por...', '一张面具背后的理想与革命。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1465235231.jpg');
INSERT INTO `movieinfo` VALUES (66, '让子弹飞', '8.8', '1176875人评价', '导演: 姜文 Wen Jiang   主演: 姜文 Wen Jiang / 葛优 You Ge / 周润发 Yun-F...', '你给我翻译翻译，神马叫做TMD的惊喜。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1512562287.jpg');
INSERT INTO `movieinfo` VALUES (67, '看不见的客人', '8.8', '855516人评价', '导演: 奥里奥尔·保罗 Oriol Paulo   主演: 马里奥·卡萨斯 Mario Casas / 阿...', '你以为你以为的就是你以为的。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2498971355.jpg');
INSERT INTO `movieinfo` VALUES (68, '绿皮书', '8.9', '1112547人评价', '导演: 彼得·法雷里 Peter Farrelly   主演: 维果·莫腾森 Viggo Mortensen /...', '去除成见，需要勇气。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2549177902.jpg');
INSERT INTO `movieinfo` VALUES (69, '西西里的美丽传说', '8.9', '711987人评价', '导演: 朱塞佩·托纳多雷 Giuseppe Tornatore   主演: 莫妮卡·贝鲁奇 Monica ...', '美丽无罪。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2448029416.jpg');
INSERT INTO `movieinfo` VALUES (70, '小鞋子', '9.2', '292571人评价', '导演: 马基德·马基迪 Majid Majidi   主演: 法拉赫阿米尔·哈什米安 Amir Fa...', '奔跑的孩子是天使。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2173580536.jpg');
INSERT INTO `movieinfo` VALUES (71, '拯救大兵瑞恩', '9.0', '467875人评价', '导演: 史蒂文·斯皮尔伯格 Steven Spielberg   主演: 汤姆·汉克斯 Tom Hanks...', '美利坚精神输出大片No1.', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1014542496.jpg');
INSERT INTO `movieinfo` VALUES (73, '海蒂和爷爷', '9.2', '289972人评价', '导演: 阿兰·葛斯彭纳 Alain Gsponer   主演: 阿努克·斯特芬 Anuk Steffen /...', '如果生活中有什么使你感到快乐，那就去做吧！不要管别人说什么。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2554525534.jpg');
INSERT INTO `movieinfo` VALUES (74, '情书', '8.9', '662019人评价', '导演: 岩井俊二 Shunji Iwai   主演: 中山美穗 Miho Nakayama / 丰川悦司 Ets...', '暗恋的极致。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p449897379.jpg');
INSERT INTO `movieinfo` VALUES (75, '穿条纹睡衣的男孩', '9.1', '362640人评价', '导演: 马克·赫尔曼 Mark Herman   主演: 阿萨·巴特菲尔德 Asa Butterfield ...', '尽管有些不切实际的幻想，这部电影依旧是一部感人肺腑的佳作。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1473670352.jpg');
INSERT INTO `movieinfo` VALUES (76, '音乐之声', '9.0', '435931人评价', '导演: 罗伯特·怀斯 Robert Wise   主演: 朱莉·安德鲁斯 Julie Andrews / 克...', '用音乐化解仇恨，让歌声串起美好。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p453788577.jpg');
INSERT INTO `movieinfo` VALUES (77, '美国往事', '9.2', '306271人评价', '导演: 赛尔乔·莱翁内 Sergio Leone   主演: 罗伯特·德尼罗 Robert De Niro ...', '往事如烟，无处祭奠。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p477229647.jpg');
INSERT INTO `movieinfo` VALUES (78, '致命魔术', '8.9', '619507人评价', '导演: 克里斯托弗·诺兰 Christopher Nolan   主演: 休·杰克曼 Hugh Jackman...', '孪生蝙蝠侠大战克隆金刚狼。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p480383375.jpg');
INSERT INTO `movieinfo` VALUES (79, '低俗小说', '8.8', '609701人评价', '导演: 昆汀·塔伦蒂诺 Quentin Tarantino   主演: 约翰·特拉沃尔塔 John Tra...', '故事的高级讲法。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1910902213.jpg');
INSERT INTO `movieinfo` VALUES (80, '七宗罪', '8.8', '714522人评价', '导演: 大卫·芬奇 David Fincher   主演: 摩根·弗里曼 Morgan Freeman / 布...', '警察抓小偷，老鼠玩死猫。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2219586434.jpg');
INSERT INTO `movieinfo` VALUES (81, '沉默的羔羊', '8.8', '615751人评价', '导演: 乔纳森·戴米 Jonathan Demme   主演: 朱迪·福斯特 Jodie Foster / 安...', '安东尼·霍普金斯的顶级表演。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1593414327.jpg');
INSERT INTO `movieinfo` VALUES (82, '蝴蝶效应', '8.8', '679968人评价', '导演: 埃里克·布雷斯 Eric Bress / J·麦基·格鲁伯 J. Mackye Gruber   主...', '人的命运被自己瞬间的抉择改变。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2209066019.jpg');
INSERT INTO `movieinfo` VALUES (83, '禁闭岛', '8.8', '684100人评价', '导演: Martin Scorsese   主演: 莱昂纳多·迪卡普里奥 Leonardo DiCaprio / ...', '昔日翩翩少年，今日大腹便便。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1832875827.jpg');
INSERT INTO `movieinfo` VALUES (84, '心灵捕手', '8.9', '511456人评价', '导演: 格斯·范·桑特 Gus Van Sant   主演: 马特·达蒙 Matt Damon / 罗宾·...', '人生中应该拥有这样的一段豁然开朗。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p480965695.jpg');
INSERT INTO `movieinfo` VALUES (85, '春光乍泄', '8.9', '459269人评价', '导演: 王家卫 Kar Wai Wong   主演: 张国荣 Leslie Cheung / 梁朝伟 Tony Leu...', '爱情纠缠，男女一致。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p465939041.jpg');
INSERT INTO `movieinfo` VALUES (86, '布达佩斯大饭店', '8.8', '645301人评价', '导演: 韦斯·安德森 Wes Anderson   主演: 拉尔夫·费因斯 Ralph Fiennes / ...', '小清新的故事里注入了大历史的情怀。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2178872593.jpg');
INSERT INTO `movieinfo` VALUES (87, '被嫌弃的松子的一生', '8.9', '547297人评价', '导演: 中岛哲也 Tetsuya Nakashima   主演: 中谷美纪 Miki Nakatani / 瑛太 E...', '以戏谑来戏谑戏谑。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p884763596.jpg');
INSERT INTO `movieinfo` VALUES (88, '阿凡达', '8.7', '970066人评价', '导演: 詹姆斯·卡梅隆 James Cameron   主演: 萨姆·沃辛顿 Sam Worthington ...', '绝对意义上的美轮美奂。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2180085848.jpg');
INSERT INTO `movieinfo` VALUES (89, '摩登时代', '9.3', '203797人评价', '导演: 查理·卓别林 Charles Chaplin   主演: 查理·卓别林 Charles Chaplin ...', '大时代中的人生，小人物的悲喜。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2263408369.jpg');
INSERT INTO `movieinfo` VALUES (90, '剪刀手爱德华', '8.7', '819653人评价', '导演: 蒂姆·波顿 Tim Burton   主演: 约翰尼·德普 Johnny Depp / 薇诺娜·...', '浪漫忧郁的成人童话。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p480956937.jpg');
INSERT INTO `movieinfo` VALUES (91, '勇敢的心', '8.9', '450790人评价', '导演: 梅尔·吉布森 Mel Gibson   主演: 梅尔·吉布森 Mel Gibson / 苏菲·玛...', '史诗大片的典范。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2218094815.jpg');
INSERT INTO `movieinfo` VALUES (92, '喜剧之王', '8.7', '686239人评价', '导演: 周星驰 Stephen Chow / 李力持 Lik-Chi Lee   主演: 周星驰 Stephen Ch...', '我是一个演员。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2579932167.jpg');
INSERT INTO `movieinfo` VALUES (93, '天使爱美丽', '8.7', '781543人评价', '导演: 让-皮埃尔·热内 Jean-Pierre Jeunet   主演: 奥黛丽·塔图 Audrey Tau...', '法式小清新。 ', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2447590313.jpg');
INSERT INTO `movieinfo` VALUES (94, '致命ID', '8.8', '576343人评价', '导演: 詹姆斯·曼高德 James Mangold   主演: 约翰·库萨克 John Cusack / 雷...', '最不可能的那个人永远是最可能的。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2558364386.jpg');
INSERT INTO `movieinfo` VALUES (95, '加勒比海盗', '8.8', '645377人评价', '导演: 戈尔·维宾斯基 Gore Verbinski   主演: 约翰尼·德普 Johnny Depp / ...', '约翰尼·德普的独角戏。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1596085504.jpg');
INSERT INTO `movieinfo` VALUES (96, '哈利·波特与死亡圣器(下)', '8.8', '547105人评价', '导演: 大卫·叶茨 David Yates   主演: 丹尼尔·雷德克里夫 Daniel Radcliffe...', '10年的完美句点。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p917846733.jpg');
INSERT INTO `movieinfo` VALUES (97, '断背山', '8.8', '544572人评价', '导演: 李安 Ang Lee   主演: 希斯·莱杰 Heath Ledger / 杰克·吉伦哈尔 Jake...', '每个人心中都有一座断背山。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2514704949.jpg');
INSERT INTO `movieinfo` VALUES (98, '杀人回忆', '8.8', '478919人评价', '导演: 奉俊昊 Joon-ho Bong   主演: 宋康昊 Kang-ho Song / 金相庆 Sang-kyun...', '关于连环杀人悬案的集体回忆。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p657823840.jpg');
INSERT INTO `movieinfo` VALUES (99, '狩猎', '9.1', '260509人评价', '导演: 托马斯·温特伯格 Thomas Vinterberg   主演: 麦斯·米科尔森 Mads Mik...', '人言可畏。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1546987967.jpg');
INSERT INTO `movieinfo` VALUES (100, '请以你的名字呼唤我', '8.9', '466412人评价', '导演: 卢卡·瓜达尼诺 Luca Guadagnino   主演: 艾米·汉莫 Armie Hammer / ...', '沉醉在电影的情感和视听氛围中无法自拔。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2505525050.jpg');
INSERT INTO `movieinfo` VALUES (101, '幽灵公主', '8.9', '400424人评价', '导演: 宫崎骏 Hayao Miyazaki   主演: 松田洋治 Yôji Matsuda / 石田百合...', '人与自然的战争史诗。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1613191025.jpg');
INSERT INTO `movieinfo` VALUES (102, '阳光灿烂的日子', '8.8', '461581人评价', '导演: 姜文 Wen Jiang   主演: 夏雨 Yu Xia / 宁静 Jing Ning / 陶虹 Hong Tao', '一场华丽的意淫。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2564685215.jpg');
INSERT INTO `movieinfo` VALUES (103, '小森林 夏秋篇', '9.0', '306653人评价', '导演: 森淳一 Junichi Mori   主演: 桥本爱 Ai Hashimoto / 三浦贵大 Takahir...', '那些静得只能听见呼吸的日子里，你明白孤独即生活。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2564498893.jpg');
INSERT INTO `movieinfo` VALUES (104, '7号房的礼物', '8.9', '379363人评价', '导演: 李焕庆 Hwan-kyeong Lee   主演: 柳承龙 Seung-yong Ryoo / 朴信惠 Shi...', '《我是山姆》的《美丽人生》。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1816276065.jpg');
INSERT INTO `movieinfo` VALUES (105, '重庆森林', '8.7', '582101人评价', '导演: 王家卫 Kar Wai Wong   主演: 林青霞 Brigitte Lin / 金城武 Takeshi K...', '寂寞没有期限。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p792381411.jpg');
INSERT INTO `movieinfo` VALUES (106, '第六感', '8.9', '397595人评价', '导演: M·奈特·沙马兰 M. Night Shyamalan   主演: 布鲁斯·威利斯 Bruce Wi...', '深入内心的恐怖，出人意料的结局。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2220184425.jpg');
INSERT INTO `movieinfo` VALUES (107, '入殓师', '8.8', '453955人评价', '导演: 泷田洋二郎 Yôjirô Takita   主演: 本木雅弘 Masahiro Motoki / ...', '死可能是一道门，逝去并不是终结，而是超越，走向下一程。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1583839859.jpg');
INSERT INTO `movieinfo` VALUES (108, '红辣椒', '9.0', '284939人评价', '导演: 今敏 Satoshi Kon   主演: 林原惠美 Megumi Hayashibara / 江守彻 Toru...', '梦的勾结。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p456825720.jpg');
INSERT INTO `movieinfo` VALUES (109, '小森林 冬春篇', '9.0', '270927人评价', '导演: 森淳一 Junichi Mori   主演: 桥本爱 Ai Hashimoto / 三浦贵大 Takahir...', '尊敬他人，尊敬你生活的这片土地，明白孤独是人生的常态。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2258078370.jpg');
INSERT INTO `movieinfo` VALUES (110, '消失的爱人', '8.7', '654347人评价', '导演: 大卫·芬奇 David Fincher   主演: 本·阿弗莱克 Ben Affleck / 罗莎蒙...', '年度最佳date movie。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2221768894.jpg');
INSERT INTO `movieinfo` VALUES (111, '爱在黎明破晓前', '8.8', '435352人评价', '导演: 理查德·林克莱特 Richard Linklater   主演: 伊桑·霍克 Ethan Hawke ...', '缘分是个连绵词，最美不过一瞬。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2555762374.jpg');
INSERT INTO `movieinfo` VALUES (112, '一一', '9.0', '258699人评价', '导演: 杨德昌 Edward Yang   主演: 吴念真 / 李凯莉 Kelly Lee / 金燕玲 Elai...', '我们都曾经是一一。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2567845803.jpg');
INSERT INTO `movieinfo` VALUES (113, '侧耳倾听', '8.9', '334970人评价', '导演: 近藤喜文 Yoshifumi Kondo   主演: 本名阳子 Youko Honna / 小林桂树 K...', '少女情怀总是诗。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p456692072.jpg');
INSERT INTO `movieinfo` VALUES (114, '唐伯虎点秋香', '8.6', '744980人评价', '导演: 李力持 Lik-Chi Lee   主演: 周星驰 Stephen Chow / 巩俐 Li Gong / 陈...', '华太师是黄霑，吴镇宇四大才子之一。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2357915564.jpg');
INSERT INTO `movieinfo` VALUES (115, '超脱', '8.9', '340224人评价', '导演: 托尼·凯耶 Tony Kaye   主演: 艾德里安·布洛迪 Adrien Brody / 马西...', '穷尽一生，我们要学会的，不过是彼此拥抱。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1305562621.jpg');
INSERT INTO `movieinfo` VALUES (116, '倩女幽魂', '8.7', '527360人评价', '导演: 程小东 Siu-Tung Ching   主演: 张国荣 Leslie Cheung / 王祖贤 Joey W...', '两张绝世的脸。 ', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2414157745.jpg');
INSERT INTO `movieinfo` VALUES (117, '蝙蝠侠：黑暗骑士崛起', '8.8', '519814人评价', '导演: 克里斯托弗·诺兰 Christopher Nolan   主演: 克里斯蒂安·贝尔 Christ...', '诺兰就是保证。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1706428744.jpg');
INSERT INTO `movieinfo` VALUES (118, '玛丽和马克思', '8.9', '336871人评价', '导演: 亚当·艾略特 Adam Elliot   主演: 托妮·科莱特 Toni Collette / 菲利...', '你是我最好的朋友，你是我唯一的朋友 。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2162822165.jpg');
INSERT INTO `movieinfo` VALUES (119, '告白', '8.7', '543470人评价', '导演: 中岛哲也 Tetsuya Nakashima   主演: 松隆子 Takako Matsu / 冈田将生 ...', '没有一人完全善，也没有一人完全恶。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p689520756.jpg');
INSERT INTO `movieinfo` VALUES (120, '甜蜜蜜', '8.8', '380169人评价', '导演: 陈可辛 Peter Chan   主演: 黎明 Leon Lai / 张曼玉 Maggie Cheung / ...', '相逢只要一瞬间，等待却像是一辈子。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2223011274.jpg');
INSERT INTO `movieinfo` VALUES (121, '无人知晓', '9.1', '200649人评价', '导演: 是枝裕和 Hirokazu Koreeda   主演: 柳乐优弥 Yûya Yagira / 北浦爱...', '我的平常生活就是他人的幸福。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p661160053.jpg');
INSERT INTO `movieinfo` VALUES (122, '大鱼', '8.8', '428548人评价', '导演: 蒂姆·波顿 Tim Burton   主演: 伊万·麦克格雷格 Ewan McGregor / 阿...', '抱着梦想而活着的人是幸福的，怀抱梦想而死去的人是不朽的。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p692813374.jpg');
INSERT INTO `movieinfo` VALUES (123, '阳光姐妹淘', '8.8', '464062人评价', '导演: 姜炯哲 Hyeong-Cheol Kang   主演: 沈恩京 Eun-kyung Shim / 闵孝琳 Hy...', '再多各自牛逼的时光，也比不上一起傻逼的岁月。 ', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1374786017.jpg');
INSERT INTO `movieinfo` VALUES (124, '萤火之森', '8.9', '362996人评价', '导演: 大森贵弘 Takahiro Omori   主演: 佐仓绫音 Ayane Sakura / 内山昂辉 K...', '触不到的恋人。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1675053073.jpg');
INSERT INTO `movieinfo` VALUES (125, '超能陆战队', '8.7', '722490人评价', '导演: 唐·霍尔 Don Hall / 克里斯·威廉姆斯 Chris Williams   主演: 斯科特...', 'Balalala~~~', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2614500883.jpg');
INSERT INTO `movieinfo` VALUES (126, '驯龙高手', '8.7', '557349人评价', '导演: 迪恩·德布洛斯 Dean DeBlois / 克里斯·桑德斯 Chris Sanders   主演:...', '和谐的生活离不开摸头与被摸头。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2210954024.jpg');
INSERT INTO `movieinfo` VALUES (127, '射雕英雄传之东成西就', '8.7', '477308人评价', '导演: 刘镇伟 Jeffrey Lau   主演: 梁朝伟 Tony Leung Chiu Wai / 林青霞 Bri...', '百看不厌。 ', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2609063925.jpg');
INSERT INTO `movieinfo` VALUES (128, '借东西的小人阿莉埃蒂', '8.8', '395171人评价', '导演: 米林宏昌 Hiromasa Yonebayashi   主演: 志田未来 Mirai Shida / 神木...', '曾经的那段美好会沉淀为一辈子的记忆。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p617533616.jpg');
INSERT INTO `movieinfo` VALUES (129, '幸福终点站', '8.8', '395911人评价', '导演: 史蒂文·斯皮尔伯格 Steven Spielberg   主演: 汤姆·汉克斯 Tom Hanks...', '有时候幸福需要等一等。 ', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p854757687.jpg');
INSERT INTO `movieinfo` VALUES (130, '菊次郎的夏天', '8.8', '375526人评价', '导演: 北野武 Takeshi Kitano   主演: 北野武 Takeshi Kitano / 关口雄介 Yus...', '从没见过那么流氓的温柔，从没见过那么温柔的流氓。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p751835224.jpg');
INSERT INTO `movieinfo` VALUES (131, '爱在日落黄昏时', '8.8', '368311人评价', '导演: 理查德·林克莱特 Richard Linklater   主演: 伊桑·霍克 Ethan Hawke ...', '九年后的重逢是世俗和责任的交叠，没了悸动和青涩，沧桑而温暖。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2561542458.jpg');
INSERT INTO `movieinfo` VALUES (132, '恐怖直播', '8.8', '461251人评价', '导演: 金秉祐 Byeong-woo Kim   主演: 河正宇 Jung-woo Ha / 李璟荣 Kyeong-y...', '恐怖分子的“秋菊打官司”。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2016930906.jpg');
INSERT INTO `movieinfo` VALUES (133, '完美的世界', '9.1', '187891人评价', '导演: 克林特·伊斯特伍德 Clint Eastwood   主演: 凯文·科斯特纳 Kevin Cos...', '坏人的好总是比好人的好来得更感人。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2190556408.jpg');
INSERT INTO `movieinfo` VALUES (134, '功夫', '8.6', '695847人评价', '导演: 周星驰 Stephen Chow   主演: 周星驰 Stephen Chow / 元秋 Qiu Yuen / ...', '警恶惩奸，维护世界和平这个任务就交给你了，好吗？', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2219011938.jpg');
INSERT INTO `movieinfo` VALUES (135, '人生果实', '9.5', '101561人评价', '导演: 伏原健之 Kenshi Fushihara   主演: 津端修一 Shûichi Tsubata / 津...', '土壤没有落叶不会肥沃，没有了你就不算人生。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2544912792.jpg');
INSERT INTO `movieinfo` VALUES (137, '怪兽电力公司', '8.7', '470916人评价', '导演: 彼特·道格特 Pete Docter / 大卫·斯沃曼 David Silverman   主演: 约...', '不要给它起名字，起了名字就有感情了。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2513247938.jpg');
INSERT INTO `movieinfo` VALUES (138, '玩具总动员3', '8.8', '364982人评价', '导演: 李·昂克里奇 Lee Unkrich   主演: 汤姆·汉克斯 Tom Hanks / 蒂姆·艾...', '跨度十五年的欢乐与泪水。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1283675359.jpg');
INSERT INTO `movieinfo` VALUES (139, '傲慢与偏见', '8.6', '559366人评价', '导演: 乔·怀特 Joe Wright   主演: 凯拉·奈特莉 Keira Knightley / 马修·...', '爱是摈弃傲慢与偏见之后的曙光。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2016401659.jpg');
INSERT INTO `movieinfo` VALUES (140, '血战钢锯岭', '8.7', '587708人评价', '导演: 梅尔·吉布森 Mel Gibson   主演: 安德鲁·加菲尔德 Andrew Garfield /...', '优秀的战争片不会美化战场，不会粉饰死亡，不会矮化敌人，不会无视常识，最重要的，不会宣扬战争。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2398141939.jpg');
INSERT INTO `movieinfo` VALUES (141, '天书奇谭', '9.2', '153096人评价', '导演: 王树忱 Shuchen Wang / 钱运达 Yunda Qian   主演: 丁建华 Jianhua Din...', '传奇的年代，醉人的童话。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2515539487.jpg');
INSERT INTO `movieinfo` VALUES (142, '风之谷', '8.9', '284834人评价', '导演: 宫崎骏 Hayao Miyazaki   主演: 岛本须美 Sumi Shimamoto / 松田洋治 Y...', '动画片的圣经。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1917567652.jpg');
INSERT INTO `movieinfo` VALUES (143, '教父3', '8.9', '252463人评价', '导演: 弗朗西斯·福特·科波拉 Francis Ford Coppola   主演: 阿尔·帕西诺 A...', '任何信念的力量，都无法改变命运。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2169664351.jpg');
INSERT INTO `movieinfo` VALUES (144, '时空恋旅人', '8.7', '402879人评价', '导演: 理查德·柯蒂斯 Richard Curtis   主演: 多姆纳尔·格里森 Domhnall Gl...', '把每天当作最后一天般珍惜度过，积极拥抱生活，就是幸福。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2070153774.jpg');
INSERT INTO `movieinfo` VALUES (145, '上帝之城', '8.9', '233627人评价', '导演: 费尔南多·梅里尔斯 Fernando Meirelles / 卡迪亚·兰德 Kátia Lund  &nbsp...', '被上帝抛弃了的上帝之城。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p455677490.jpg');
INSERT INTO `movieinfo` VALUES (146, '电锯惊魂', '8.7', '366152人评价', '导演: 詹姆斯·温 James Wan   主演: 雷·沃纳尔 Leigh Whannell / 加利·艾...', '真相就在眼前。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1421159978.jpg');
INSERT INTO `movieinfo` VALUES (147, '被解救的姜戈', '8.7', '445516人评价', '导演: 昆汀·塔伦蒂诺 Quentin Tarantino   主演: 杰米·福克斯 Jamie Foxx /...', '热血沸腾，那个低俗、性感的无耻混蛋又来了。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1959232369.jpg');
INSERT INTO `movieinfo` VALUES (148, '喜宴', '8.9', '244689人评价', '导演: 李安 Ang Lee   主演: 赵文瑄 Winston Chao / 郎雄 Sihung Lung / 归亚...', '中国家庭的喜怒哀乐忍。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2173713676.jpg');
INSERT INTO `movieinfo` VALUES (149, '哪吒闹海', '9.1', '179655人评价', '导演: 严定宪 Dingxian Yan / 王树忱 Shuchen Wang   主演: 梁正晖 Zhenghui ...', '想你时你在闹海。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2516566783.jpg');
INSERT INTO `movieinfo` VALUES (150, '釜山行', '8.5', '829827人评价', '导演: 延尚昊 Sang-ho Yeon   主演: 孔侑 Yoo Gong / 郑有美 Yu-mi Jung / 马...', '揭露人性的丧尸题材力作。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2360940399.jpg');
INSERT INTO `movieinfo` VALUES (151, '七武士', '9.2', '137221人评价', '导演: 黑泽明 Akira Kurosawa   主演: 三船敏郎 Toshirô Mifune / 志村乔 ...', '时代悲歌。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2215886505.jpg');
INSERT INTO `movieinfo` VALUES (152, '英雄本色', '8.7', '367723人评价', '导演: 吴宇森 John Woo   主演: 周润发 Yun-Fat Chow / 狄龙 Lung Ti / 张国...', '英雄泪短，兄弟情长。 ', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2504997087.jpg');
INSERT INTO `movieinfo` VALUES (153, '谍影重重3', '8.8', '313952人评价', '导演: 保罗·格林格拉斯 Paul Greengrass   主演: 马特·达蒙 Matt Damon / ...', '像吃了苏打饼一样干脆的电影。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p792223507.jpg');
INSERT INTO `movieinfo` VALUES (154, '我是山姆', '8.9', '221107人评价', '导演: 杰茜·尼尔森 Jessie Nelson   主演: Sean Penn / Dakota Fanning / Mi...', '爱并不需要智商 。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p652417775.jpg');
INSERT INTO `movieinfo` VALUES (155, '岁月神偷', '8.7', '465080人评价', '导演: 罗启锐 Alex Law   主演: 吴君如 Sandra Ng / 任达华 Simon Yam / 钟绍...', '岁月流逝，来日可追。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p659427316.jpg');
INSERT INTO `movieinfo` VALUES (156, '哈利·波特与阿兹卡班的囚徒', '8.7', '408939人评价', '导演: Alfonso Cuarón   主演: 丹尼尔·雷德克里夫 Daniel Radcliffe / Emma...', '不一样的导演，不一样的哈利·波特。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1910812549.jpg');
INSERT INTO `movieinfo` VALUES (157, '头号玩家', '8.7', '1032556人评价', '导演: 史蒂文·斯皮尔伯格 Steven Spielberg   主演: 泰伊·谢里丹 Tye Sheri...', '写给影迷，动漫迷和游戏迷的一封情书。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2516578307.jpg');
INSERT INTO `movieinfo` VALUES (158, '纵横四海', '8.8', '296425人评价', '导演: 吴宇森 John Woo   主演: 周润发 Yun-Fat Chow / 张国荣 Leslie Cheung...', '香港浪漫主义警匪动作片的巅峰之作。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2597918718.jpg');
INSERT INTO `movieinfo` VALUES (159, '疯狂原始人', '8.7', '630526人评价', '导演: 科克·德·米科 Kirk De Micco / 克里斯·桑德斯 Chris Sanders   主演...', '老少皆宜，这就是好莱坞动画的魅力。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1867084027.jpg');
INSERT INTO `movieinfo` VALUES (160, '三块广告牌', '8.7', '615542人评价', '导演: 马丁·麦克唐纳 Martin McDonagh   主演: 弗兰西斯·麦克多蒙德 France...', '怼天怼地，你走后，她与世界为敌。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2510081688.jpg');
INSERT INTO `movieinfo` VALUES (161, '心迷宫', '8.7', '358778人评价', '导演: 忻钰坤 Yukun Xin   主演: 霍卫民 Weimin Huo / 王笑天 Xiaotian Wang ...', '荒诞讽刺，千奇百巧，抽丝剥茧，百转千回。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2276780256.jpg');
INSERT INTO `movieinfo` VALUES (162, '一个叫欧维的男人决定去死', '8.8', '279280人评价', '导演: 汉内斯·赫尔姆 Hannes Holm   主演: 罗夫·拉斯加德 Rolf Lassgård...', '惠及一生的美丽。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2406624993.jpg');
INSERT INTO `movieinfo` VALUES (163, '达拉斯买家俱乐部', '8.8', '329505人评价', '导演: 让-马克·瓦雷 Jean-Marc Vallée   主演: 马修·麦康纳 Matthew McCon...', 'Jared Leto的腿比女人还美！', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2166160837.jpg');
INSERT INTO `movieinfo` VALUES (164, '卢旺达饭店', '8.9', '216166人评价', '导演: 特瑞·乔治 Terry George   主演: 唐·钱德尔 Don Cheadle / 苏菲·奥...', '当这个世界闭上双眼，他却敞开了怀抱。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p470419493.jpg');
INSERT INTO `movieinfo` VALUES (165, '萤火虫之墓', '8.7', '325436人评价', '导演: 高畑勋 Isao Takahata   主演: 辰己努 / 白石绫乃 / 志乃原良子', '幸福是生生不息，却难以触及的远。 ', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1157334208.jpg');
INSERT INTO `movieinfo` VALUES (166, '荒蛮故事', '8.8', '306146人评价', '导演: 达米安·斯兹弗隆 Damián Szifron   主演: 达里奥·葛兰帝内提 Darío...', '始于荒诞，止于更荒诞。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2584519452.jpg');
INSERT INTO `movieinfo` VALUES (167, '你的名字。', '8.4', '1007813人评价', '导演: 新海诚 Makoto Shinkai   主演: 神木隆之介 Ryûnosuke Kamiki / 上...', '穿越错位的时空，仰望陨落的星辰，你没留下你的名字，我却无法忘记那句“我爱你”。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2395733377.jpg');
INSERT INTO `movieinfo` VALUES (168, '真爱至上', '8.6', '531489人评价', '导演: 理查德·柯蒂斯 Richard Curtis   主演: 休·格兰特 Hugh Grant / 柯林...', '爱，是个动词。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p475600770.jpg');
INSERT INTO `movieinfo` VALUES (169, '贫民窟的百万富翁', '8.6', '580119人评价', '导演: 丹尼·鲍尔 Danny Boyle / 洛芙琳·坦丹 Loveleen Tandan   主演: 戴夫...', '上帝之城+猜火车+阿甘正传+开心辞典=山寨富翁', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2434249040.jpg');
INSERT INTO `movieinfo` VALUES (170, '花样年华', '8.7', '417089人评价', '导演: 王家卫 Kar Wai Wong   主演: 梁朝伟 Tony Leung Chiu Wai / 张曼玉 Ma...', '偷情本没有这样美。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1910828286.jpg');
INSERT INTO `movieinfo` VALUES (171, '记忆碎片', '8.6', '448352人评价', '导演: 克里斯托弗·诺兰 Christopher Nolan   主演: 盖·皮尔斯 Guy Pearce /...', '一个针管引发的血案。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p641688453.jpg');
INSERT INTO `movieinfo` VALUES (172, '东邪西毒', '8.6', '442496人评价', '导演: 王家卫 Kar Wai Wong   主演: 张国荣 Leslie Cheung / 林青霞 Brigitte...', '电影诗。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1982176012.jpg');
INSERT INTO `movieinfo` VALUES (173, '爆裂鼓手', '8.7', '407016人评价', '导演: 达米恩·查泽雷 Damien Chazelle   主演: 迈尔斯·特勒 Miles Teller /...', '这个世界从不善待努力的人，努力了也不一定会成功，但是知道自己在努力，就是活下去的动力。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2220776342.jpg');
INSERT INTO `movieinfo` VALUES (174, '哈利·波特与密室', '8.6', '428115人评价', '导演: Chris Columbus   主演: 丹尼尔·雷德克里夫 Daniel Radcliffe / 艾玛...', '魔法的密室之门已打开...', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1082651990.jpg');
INSERT INTO `movieinfo` VALUES (175, '黑天鹅', '8.6', '641497人评价', '导演: 达伦·阿罗诺夫斯基 Darren Aronofsky   主演: 娜塔莉·波特曼 Natalie...', '黑暗之美。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2549648344.jpg');
INSERT INTO `movieinfo` VALUES (176, '黑客帝国3：矩阵革命', '8.8', '305573人评价', '导演: Andy Wachowski / Larry Wachowski   主演: 基努·里维斯 Keanu Reeves...', '不得不说，《黑客帝国》系列是商业片与科幻、哲学完美结合的典范。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2220873438.jpg');
INSERT INTO `movieinfo` VALUES (177, '忠犬八公物语', '9.2', '135353人评价', '导演: Seijirô Kôyama   主演: 山本圭 Kei Yamamoto / 井川比佐志 Hisa...', '养狗三日，便会对你终其一生。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1576418852.jpg');
INSERT INTO `movieinfo` VALUES (178, '模仿游戏', '8.7', '441996人评价', '导演: 莫滕·泰杜姆 Morten Tyldum   主演: 本尼迪克特·康伯巴奇 Benedict C...', '他给机器起名“克里斯托弗”，因为这是他初恋的名字。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2255040492.jpg');
INSERT INTO `movieinfo` VALUES (179, '头脑特工队', '8.7', '426393人评价', '导演: 彼特·道格特 Pete Docter / 罗纳尔多·德尔·卡门 Ronaldo Del Carmen  &nb...', '愿我们都不用长大，每一座城堡都能永远存在。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2266293606.jpg');
INSERT INTO `movieinfo` VALUES (180, '新世界', '8.8', '242347人评价', '导演: 朴勋政 Hoon-jung Park   主演: 李政宰 Jung-Jae Lee / 崔岷植 Min-sik...', '要做就做得狠一点，这样才能活下去。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1903379979.jpg');
INSERT INTO `movieinfo` VALUES (181, '未麻的部屋', '8.9', '192523人评价', '导演: 今敏 Satoshi Kon   主演: 岩男润子 Junko Iwao / 松本梨香 Rica Matsu...', '好的剧本是，就算你猜到了结局也猜不到全部。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1351050722.jpg');
INSERT INTO `movieinfo` VALUES (182, '你看起来好像很好吃', '8.9', '252042人评价', '导演: 藤森雅也 Masaya Fujimori   主演: 山口胜平 Kappei Yamaguchi / 爱河...', '感情不分食草或者食肉。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p709670262.jpg');
INSERT INTO `movieinfo` VALUES (183, '雨人', '8.7', '313604人评价', '导演: 巴瑞·莱文森 Barry Levinson   主演: 达斯汀·霍夫曼 Dustin Hoffman ...', '生活在自己的世界里，也可以让周围的人显得可笑和渺小。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2353324612.jpg');
INSERT INTO `movieinfo` VALUES (184, '无敌破坏王', '8.7', '389331人评价', '导演: 瑞奇·莫尔 Rich Moore   主演: 约翰·C·赖利 John C. Reilly / 萨拉...', '迪士尼和皮克斯拿错剧本的产物。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1735642656.jpg');
INSERT INTO `movieinfo` VALUES (185, '海街日记', '8.8', '290112人评价', '导演: 是枝裕和 Hirokazu Koreeda   主演: 绫濑遥 Haruka Ayase / 长泽雅美 M...', '是枝裕和的家庭习作。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2242546753.jpg');
INSERT INTO `movieinfo` VALUES (186, '冰川时代', '8.6', '465700人评价', '导演: 卡洛斯·沙尔丹哈 Carlos Saldanha / 克里斯·韦奇 Chris Wedge   主演...', '松鼠才是角儿。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1910895719.jpg');
INSERT INTO `movieinfo` VALUES (187, '恋恋笔记本', '8.5', '485218人评价', '导演: 尼克·卡索维茨 Nick Cassavetes   主演: 瑞恩·高斯林 Ryan Gosling /...', '爱情没有那么多借口，如果不能圆满，只能说明爱的不够。 ', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p483604864.jpg');
INSERT INTO `movieinfo` VALUES (188, '惊魂记', '9.0', '171099人评价', '导演: 阿尔弗雷德·希区柯克 Alfred Hitchcock   主演: 安东尼·博金斯 Antho...', '故事的反转与反转，分裂电影的始祖。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1021883305.jpg');
INSERT INTO `movieinfo` VALUES (189, '二十二', '8.7', '217804人评价', '导演: 郭柯 Ke Guo   主演:', '有一些东西不应该被遗忘。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2457609817.jpg');
INSERT INTO `movieinfo` VALUES (190, '海边的曼彻斯特', '8.6', '359512人评价', '导演: 肯尼斯·罗纳根 Kenneth Lonergan   主演: 卡西·阿弗莱克 Casey Affle...', '我们都有权利不与自己的过去和解。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2421855655.jpg');
INSERT INTO `movieinfo` VALUES (191, '恐怖游轮', '8.5', '578750人评价', '导演: 克里斯托弗·史密斯 Christopher Smith   主演: 梅利莎·乔治 Melissa ...', '不要企图在重复中寻找已经失去的爱。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p462470694.jpg');
INSERT INTO `movieinfo` VALUES (192, '房间', '8.8', '292872人评价', '导演: 伦尼·阿伯拉罕森 Lenny Abrahamson   主演: 布丽·拉尔森 Brie Larson...', '被偷走的岁月，被伤害的生命，被禁锢的灵魂，终将被希望和善意救赎。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2259715855.jpg');
INSERT INTO `movieinfo` VALUES (193, '奇迹男孩', '8.6', '424250人评价', '导演: 斯蒂芬·卓博斯基 Stephen Chbosky   主演: 雅各布·特伦布莱 Jacob Tr...', '世界不完美，爱会有奇迹。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2507709428.jpg');
INSERT INTO `movieinfo` VALUES (194, '虎口脱险', '8.9', '173474人评价', '导演: 杰拉尔·乌里 Gérard Oury   主演: 路易·德·菲耐斯 Louis de Funès...', '永远看不腻的喜剧。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2399597512.jpg');
INSERT INTO `movieinfo` VALUES (195, '魔女宅急便', '8.6', '341711人评价', '导演: 宫崎骏 Hayao Miyazaki   主演: 高山南 Minami Takayama / 佐久间玲 Re...', '宫崎骏的电影总让人感觉世界是美好的，阳光明媚的。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p456676352.jpg');
INSERT INTO `movieinfo` VALUES (196, '雨中曲', '9.0', '151595人评价', '导演: 斯坦利·多南 Stanley Donen / 吉恩·凯利 Gene Kelly   主演: 吉恩·...', '骨灰级歌舞片。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1612355875.jpg');
INSERT INTO `movieinfo` VALUES (197, '小偷家族', '8.7', '598960人评价', '导演: 是枝裕和 Hirokazu Koreeda   主演: 中川雅也 Lily Franky / 安藤樱 Sa...', '我们组成了家。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2530599636.jpg');
INSERT INTO `movieinfo` VALUES (198, '疯狂的石头', '8.5', '585775人评价', '导演: 宁浩 Hao Ning   主演: 郭涛 Tao Guo / 刘桦 Hua Liu / 连晋 Teddy Lin', '中国版《两杆大烟枪》。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p712241453.jpg');
INSERT INTO `movieinfo` VALUES (199, '绿里奇迹', '8.8', '205366人评价', '导演: Frank Darabont   主演: 汤姆·汉克斯 Tom Hanks / 大卫·摩斯 David M...', '天使暂时离开。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p767586451.jpg');
INSERT INTO `movieinfo` VALUES (200, '人工智能', '8.6', '321999人评价', '导演: 史蒂文·斯皮尔伯格 Steven Spielberg   主演: 海利·乔·奥斯蒙 Haley...', '对爱的执着，可以超越一切。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p792257137.jpg');
INSERT INTO `movieinfo` VALUES (201, '爱在午夜降临前', '8.8', '237671人评价', '导演: 理查德·林克莱特 Richard Linklater   主演: 伊桑·霍克 Ethan Hawke ...', '所谓爱情，就是话唠一路，都不会心生腻烦，彼此嫌弃。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2074715729.jpg');
INSERT INTO `movieinfo` VALUES (202, '罗生门', '8.8', '223564人评价', '导演: 黑泽明 Akira Kurosawa   主演: 三船敏郎 Toshirô Mifune / 京町子 ...', '人生的N种可能性。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2564689879.jpg');
INSERT INTO `movieinfo` VALUES (203, '终结者2：审判日', '8.7', '257844人评价', '导演: 詹姆斯·卡梅隆 James Cameron   主演: 阿诺·施瓦辛格 Arnold Schwarz...', '少见的超越首部的续集，动作片中的经典。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1910909085.jpg');
INSERT INTO `movieinfo` VALUES (204, '初恋这件小事', '8.4', '774587人评价', '导演: 普特鹏·普罗萨卡·那·萨克那卡林 Puttipong Promsaka Na Sakolnakorn / 华森·波克彭...', '黑小鸭速效美白记。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p767451487.jpg');
INSERT INTO `movieinfo` VALUES (205, '海洋', '9.1', '131641人评价', '导演: 雅克·贝汉 Jacques Perrin / 雅克·克鲁奥德 Jacques Cluzaud   主演:...', '大海啊，不全是水。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2173334947.jpg');
INSERT INTO `movieinfo` VALUES (206, '魂断蓝桥', '8.8', '203890人评价', '导演: 茂文·勒鲁瓦 Mervyn LeRoy   主演: 费雯·丽 Vivien Leigh / 罗伯特·...', '中国式内在的美国电影。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2351134499.jpg');
INSERT INTO `movieinfo` VALUES (207, '可可西里', '8.8', '213516人评价', '导演: 陆川 Chuan Lu   主演: 多布杰 Duobujie / 张磊 Lei Zhang / 亓亮 Qi L...', '坚硬的信仰。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2414771522.jpg');
INSERT INTO `movieinfo` VALUES (208, '2001太空漫游', '8.8', '205957人评价', '导演: 斯坦利·库布里克 Stanley Kubrick   主演: 凯尔·杜拉 Keir Dullea / ...', '现代科幻电影的开山之作，最伟大导演的最伟大影片。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2560717825.jpg');
INSERT INTO `movieinfo` VALUES (209, '燃情岁月', '8.8', '217809人评价', '导演: 爱德华·兹威克 Edward Zwick   主演: 布拉德·皮特 Brad Pitt / 安东...', '传奇，不是每个人都可以拥有。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1023654037.jpg');
INSERT INTO `movieinfo` VALUES (210, '城市之光', '9.3', '92066人评价', '导演: Charles Chaplin   主演: 查理·卓别林 Charles Chaplin / 弗吉尼亚·...', '永远的小人物，伟大的卓别林。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2170238828.jpg');
INSERT INTO `movieinfo` VALUES (211, '穿越时空的少女', '8.6', '300323人评价', '导演: 细田守 Mamoru Hosoda   主演: 仲里依纱 Riisa Naka / 石田卓也 Takuya...', '爱上未来的你。 ', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2079334286.jpg');
INSERT INTO `movieinfo` VALUES (212, '牯岭街少年杀人事件', '8.8', '188198人评价', '导演: 杨德昌 Edward Yang   主演: 张震 Chen Chang / 杨静怡 Lisa Yang / 张...', '弱者送给弱者的一刀。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p848381236.jpg');
INSERT INTO `movieinfo` VALUES (213, '色，戒', '8.5', '496378人评价', '导演: 李安 Ang Lee   主演: 梁朝伟 Tony Leung Chiu Wai / 汤唯 Wei Tang / ...', '假戏真情，爱欲深海', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p453716305.jpg');
INSERT INTO `movieinfo` VALUES (214, '新龙门客栈', '8.6', '323914人评价', '导演: 李惠民 Raymond Lee   主演: 张曼玉 Maggie Cheung / 林青霞 Brigitte ...', '嬉笑怒骂，调风动月。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1421018669.jpg');
INSERT INTO `movieinfo` VALUES (215, '无耻混蛋', '8.6', '358402人评价', '导演: Quentin Tarantino   主演: 布拉德·皮特 Brad Pitt / 梅拉尼·罗兰 M...', '昆汀同学越来越变态了，比北野武还杜琪峰。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2575043939.jpg');
INSERT INTO `movieinfo` VALUES (216, '青蛇', '8.5', '376605人评价', '导演: 徐克 Hark Tsui   主演: 张曼玉 Maggie Cheung / 王祖贤 Joey Wang / ...', '人生如此，浮生如斯。谁人言，花彼岸，此生情长意短。谁都是不懂爱的罢了。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p584021784.jpg');
INSERT INTO `movieinfo` VALUES (217, '源代码', '8.4', '614625人评价', '导演: 邓肯·琼斯 Duncan Jones   主演: 杰克·吉伦哈尔 Jake Gyllenhaal / ...', '邓肯·琼斯继《月球》之后再度奉献出一部精彩绝伦的科幻佳作。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p988260245.jpg');
INSERT INTO `movieinfo` VALUES (218, '完美陌生人', '8.5', '408643人评价', '导演: 保罗·格诺维瑟 Paolo Genovese   主演: 马可·贾利尼 Marco Giallini ...', '来啊，互相伤害啊！', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2522331945.jpg');
INSERT INTO `movieinfo` VALUES (219, '阿飞正传', '8.5', '366407人评价', '导演: 王家卫 Kar Wai Wong   主演: 张国荣 Leslie Cheung / 张曼玉 Maggie C...', '王家卫是一种风格，张国荣是一个代表。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2525770523.jpg');
INSERT INTO `movieinfo` VALUES (220, '遗愿清单', '8.6', '274413人评价', '导演: 罗伯·莱纳 Rob Reiner   主演: 杰克·尼科尔森 Jack Nicholson / 摩根...', '用剩余不多的时间，去燃烧整个生命。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1208653481.jpg');
INSERT INTO `movieinfo` VALUES (221, '血钻', '8.7', '260710人评价', '导演: 爱德华·兹威克 Edward Zwick   主演: 莱昂纳多·迪卡普里奥 Leonardo ...', '每个美丽事物背后都是滴血的现实。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1244017073.jpg');
INSERT INTO `movieinfo` VALUES (222, '大佛普拉斯', '8.7', '281918人评价', '导演: 黄信尧 Hsin-yao Huang   主演: 庄益增 Yizeng Zhuang / 陈竹昇 Chu-sh...', '人们可以登上月球，却永远无法探索人们内心的宇宙。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2505928032.jpg');
INSERT INTO `movieinfo` VALUES (223, '谍影重重2', '8.7', '264730人评价', '导演: 保罗·格林格拉斯 Paul Greengrass   主演: 马特·达蒙 Matt Damon / ...', '谁说王家卫镜头很晃？', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p667644866.jpg');
INSERT INTO `movieinfo` VALUES (224, '香水', '8.5', '426723人评价', '导演: 汤姆·提克威 Tom Tykwer   主演: 本·卫肖 Ben Whishaw / 艾伦·瑞克...', '一个单凭体香达到高潮的男人。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2441127736.jpg');
INSERT INTO `movieinfo` VALUES (225, '地球上的星星', '8.9', '153254人评价', '导演: 阿米尔·汗 Aamir Khan   主演: 达席尔·萨法瑞 Darsheel Safary / 阿...', '天使保护事件始末。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1973489335.jpg');
INSERT INTO `movieinfo` VALUES (226, '战争之王', '8.6', '265312人评价', '导演: 安德鲁·尼科尔 Andrew Niccol   主演: 尼古拉斯·凯奇 Nicolas Cage /...', '做一颗让别人需要你的棋子。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p792282381.jpg');
INSERT INTO `movieinfo` VALUES (227, '谍影重重', '8.6', '316220人评价', '导演: 道格·里曼 Doug Liman   主演: 马特·达蒙 Matt Damon / 弗兰卡·波坦...', '哗啦啦啦啦，天在下雨，哗啦啦啦啦，云在哭泣……找自己。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1597183981.jpg');
INSERT INTO `movieinfo` VALUES (228, '疯狂的麦克斯4：狂暴之路', '8.6', '376299人评价', '导演: 乔治·米勒 George Miller   主演: 汤姆·哈迪 Tom Hardy / 查理兹·塞...', '“多么美好的一天！”轰轰轰砰咚，啪哒哒哒轰隆隆，磅~', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2236181653.jpg');
INSERT INTO `movieinfo` VALUES (230, '步履不停', '8.8', '186644人评价', '导演: 是枝裕和 Hirokazu Koreeda   主演: 阿部宽 Hiroshi Abe / 夏川结衣 Yu...', '日本的家庭电影已经是世界巅峰了，步履不停是巅峰中的佳作。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p926535516.jpg');
INSERT INTO `movieinfo` VALUES (231, '彗星来的那一夜', '8.5', '370068人评价', '导演: 詹姆斯·沃德·布柯特 James Ward Byrkit   主演: 艾米丽·芭尔多尼 Em...', '小成本大魅力。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2187896734.jpg');
INSERT INTO `movieinfo` VALUES (232, '猜火车', '8.5', '342402人评价', '导演: 丹尼·博伊尔 Danny Boyle   主演: 伊万·麦克格雷格 Ewan McGregor / ...', '不可猜的青春迷笛。 ', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p513567548.jpg');
INSERT INTO `movieinfo` VALUES (234, '朗读者', '8.6', '373709人评价', '导演: 史蒂芬·戴德利 Stephen Daldry   主演: 凯特·温丝莱特 Kate Winslet ...', '当爱情跨越年龄的界限，它似乎能变得更久远一点，成为一种责任，一种水到渠成的相濡以沫。 ', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1140984198.jpg');
INSERT INTO `movieinfo` VALUES (235, '浪潮', '8.7', '206912人评价', '导演: 丹尼斯·甘塞尔 Dennis Gansel   主演: 尤尔根·沃格尔 Jürgen Vogel ...', '世界离独裁只有五天。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1344888983.jpg');
INSERT INTO `movieinfo` VALUES (236, '小萝莉的猴神大叔', '8.4', '363503人评价', '导演: 卡比尔·汗 Kabir Khan   主演: 萨尔曼·汗 Salman Khan / 哈莎莉·马...', '宝莱坞的萝莉与大叔。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2510956726.jpg');
INSERT INTO `movieinfo` VALUES (237, '再次出发之纽约遇见你', '8.6', '310428人评价', '导演: 约翰·卡尼 John Carney   主演: 凯拉·奈特莉 Keira Knightley / 马克...', '爱我就给我看你的播放列表。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2250287733.jpg');
INSERT INTO `movieinfo` VALUES (238, '东京物语', '9.2', '93532人评价', '导演: 小津安二郎 Yasujirô Ozu   主演: 笠智众 Chishû Ryû / 原节...', '东京那么大，如果有一天走失了，恐怕一辈子不能再相见。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1925331564.jpg');
INSERT INTO `movieinfo` VALUES (239, '驴得水', '8.3', '676714人评价', '导演: 周申 Shen Zhou / 刘露 Lu Liu   主演: 任素汐 Suxi Ren / 大力 Da Li ...', '过去的如果就让它过去了，未来只会越来越糟！', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2393044761.jpg');
INSERT INTO `movieinfo` VALUES (240, '聚焦', '8.8', '212407人评价', '导演: 托马斯·麦卡锡 Thomas McCarthy   主演: 马克·鲁弗洛 Mark Ruffalo /...', '新闻人的理性求真。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2263822658.jpg');
INSERT INTO `movieinfo` VALUES (242, '追随', '8.9', '134640人评价', '导演: 克里斯托弗·诺兰 Christopher Nolan   主演: 杰里米·西奥伯德 Jeremy...', '诺兰的牛逼来源于内心散发出的恐惧。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2561545031.jpg');
INSERT INTO `movieinfo` VALUES (243, '千钧一发', '8.8', '179494人评价', '导演: 安德鲁·尼科尔 Andrew Niccol   主演: 伊桑·霍克 Ethan Hawke / 乌玛...', '一部能引人思考的科幻励志片。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2195672555.jpg');
INSERT INTO `movieinfo` VALUES (244, '我爱你', '9.0', '113118人评价', '导演: 秋昌民 Chang-min Choo   主演: 宋在河 Jae-ho Song / 李顺载 Soon-jae...', '你要相信，这世上真的有爱存在，不管在什么年纪 ', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p1075591188.jpg');
INSERT INTO `movieinfo` VALUES (245, '一次别离', '8.7', '199364人评价', '导演: 阿斯哈·法哈蒂 Asghar Farhadi   主演: 佩曼·莫阿迪 Peyman Moadi /...', '只有有信仰的人才能说出事实真相。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2189835254.jpg');
INSERT INTO `movieinfo` VALUES (246, '黑鹰坠落', '8.7', '214204人评价', '导演: 雷德利·斯科特 Ridley Scott   主演: 乔什·哈奈特 Josh Hartnett / ...', '还原真实而残酷的战争。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1910900710.jpg');
INSERT INTO `movieinfo` VALUES (247, '四个春天', '8.9', '121412人评价', '导演: 陆庆屹 Lu Qing Yi   主演: 陆运坤 Yunkun Lu / 李桂贤 Guixian Li / ...', '来也匆匆去也匆匆，就这样风雨兼程。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2540578887.jpg');
INSERT INTO `movieinfo` VALUES (249, '黑客帝国2：重装上阵', '8.6', '263452人评价', '导演: Andy Wachowski / Larry Wachowski   主演: 基努·里维斯 Keanu Reeves...', '一个精彩的世界观正在缓缓建立。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p443461390.jpg');
INSERT INTO `movieinfo` VALUES (250, '发条橙', '8.6', '284680人评价', '导演: Stanley Kubrick   主演: Malcolm McDowell / Patrick Magee / Michael...', '我完全康复了。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p529908155.jpg');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
