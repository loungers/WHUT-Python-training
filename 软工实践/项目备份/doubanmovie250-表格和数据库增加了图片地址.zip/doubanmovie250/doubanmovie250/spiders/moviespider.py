import scrapy
# 导入items.py中的DoubanmovieItem类
from doubanmovie250.items import Doubanmovie250Item


class MoviespiderSpider(scrapy.Spider):
    name = 'moviespider'
    allowed_domains = ['douban.com']
    start_urls = ['https://movie.douban.com/top250']

    def parse(self, response):
        # 获取当前页面所有的<div class = "item"></div>代码块（25个）
        movie_items = response.xpath('//div[@class="item"]')
        # 循环遍历每一个电影代码块，解析每个电影的排名和电影名称，采集数据项
        for item in movie_items:
            print(type(item))
            # 创建一个空的Doubanmovie250Item对象
            movie = Doubanmovie250Item()
            # 为对象中的属性赋值
            # rank电影排名
            movie['rank'] = item.xpath('div[@class="pic"]/em/text()').extract()
            # title电影名称
            movie['title'] = item.xpath('div[@class="info"]/div[@class="hd"]/a/span[@class="title"][1]/text()') \
                .extract()
            # rating_num电影评分
            movie['rating_num'] = item.xpath('div[@class="info"]/div[@class="bd"]/div[@class="star"]/span[2]/text()') \
                .extract()
            # comment_num评论人数
            movie['comment_num'] = item.xpath('div[@class="info"]/div[@class="bd"]/div[@class="star"]/span[last('
                                              ')]/text()').extract()
            # info主创
            movie['info'] = item.xpath('normalize-space(div[@class="info"]/div[@class="bd"]/p[@class=""][1]/text('
                                       '))').extract()
            # motto格言
            movie['motto'] = item.xpath('div[@class="info"]/div[@class="bd"]/p[@class="quote"] /span['
                                        '@class="inq"]/text()').extract()
            # 获取电影海报地址并赋值pic_url属性
            movie['pic_url'] = item.xpath('div[@class="pic"]/a/img/@src').extract()
            # 将生成好的电影数据采集对象添加到一个生成器中
            yield movie
        pass

        # 实现翻页
        # nextPage = response.xpath('//span[@class="next"]/a/@href')
        # # 判断nextPage是否有效
        # if nextPage:
        #     # 地址拼接
        #     url = response.urljoin(nextPage[0].extract())
        #     # 发送url翻页请求
        #     yield scrapy.Request(url, self.parse)
        # pass
