# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
# 导入模块
import os
import time
import json


class Doubanmovie250Pipeline:
    # 创建一个构造方法，用于创建所有项目输出文件的文件夹
    def __init__(self):
        # 设置输出文件夹名称
        self.folderName = 'output'
        # 判断文件夹是否存在
        if not os.path.exists(self.folderName):
            # 创建文件夹
            os.mkdir(self.folderName)

    def process_item(self, item, spider):
        # 输出提示
        print('>> 写入json文件...')
        # 获取当前日期的字符串类型数据
        now = time.strftime('%Y%m%d', time.localtime())
        # 设置json文件的名称
        jsonFileName = 'doubanmovie_' + now + '.json'
        try:
            # 打开json文件以追加方式
            with open(self.folderName + os.sep + jsonFileName, 'a') as jsonfile:
                # 当前数据序列化json格式
                data = json.dumps(dict(item), ensure_ascii=False) + '\n'
                # 写入到json文件
                jsonfile.write(data)
        except IOError as err:
            # 输出报错信息
            raise('json文件出错:{0}'.format(str(err)))
        finally:
            # 关闭文件流
            jsonfile.close()

        return item
