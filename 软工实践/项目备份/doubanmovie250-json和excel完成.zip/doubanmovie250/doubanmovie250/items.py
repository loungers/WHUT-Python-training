# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class Doubanmovie250Item(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    rank = scrapy.Field()  # 电影的排名
    title = scrapy.Field()  # 电影的名称
    rating_num = scrapy.Field()  # 电影评分
    comment_num = scrapy.Field()  # 评论人数
    info = scrapy.Field()  # 主创
    motto = scrapy.Field()  # 格言

    pass
