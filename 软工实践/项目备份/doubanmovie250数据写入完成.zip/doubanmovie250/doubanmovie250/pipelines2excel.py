# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface

from itemadapter import ItemAdapter

# python对于Excel操作需要第三方模块库的支持
# xlwt 实现Python对Excel的写入操作 pip install xlwt
# xlrd 实现Python对Excel读取操作
# xlutils 实现对Excel的工具包

import time
import xlwt
import xlrd
from xlutils.copy import copy


class Doubanmovie250Pipeline:
    # 构造方法 ： 创建一个Excel文件以及内容模板
    def __init__(self):
        folder_name = 'output'
        current_data = time.strftime('%Y%m%d', time.localtime())
        file_name = 'doubanmovie_' + current_data + '.xls'
        # 最终文件路径
        self.excelpath = folder_name + '/' + file_name
        # 构建workbook工作薄
        self.workbook = xlwt.Workbook(encoding='utf-8')
        # 创建sheet工作页
        self.sheet = self.workbook.add_sheet(u'豆瓣电影数据')
        # 设置Excel内容的标题
        headers = ['电影排名', '电影名称', '电影评分', '评论人数', '主创', '电影格言']
        # 设置标题文字样式
        headStyle = xlwt.easyxf('font:color-index black, bold on')
        # for 循环写入标题内容
        for colIndex in range(0, len(headers)):
            # 按照规定好的字体样式将标题内容写入
            self.sheet.write(0, colIndex, headers[colIndex], headStyle)
            pass
        # 保存创建好的Excel文件
        self.workbook.save(self.excelpath)
        # 全局变量行数
        self.rowIndex = 1
        pass

    def process_item(self, item, spider):
        print('>> 写入excel文件...')
        # 读取已经创建好的excel文件
        oldWb = xlrd.open_workbook(self.excelpath, formatting_info= True)
        # 拷贝一个副本
        newWb = copy(oldWb)
        # 获取到Excel要操作的sheet工作页
        sheet = newWb.get_sheet(0)
        # 将采集到的数据转换成一个list列表
        line = [item['rank'], item['title'], item['rating_num'], item['comment_num'], item['info'], item['motto']]
        # 使用for循环遍历excel中的每一个cell格（行，列）
        for colIndex in range(0, len(item)):
            # 将数据写入指定的行列中去
            sheet.write(self.rowIndex, colIndex, line[colIndex])
            pass
        # 完毕后保存Excel，自动覆盖原有文件
        newWb.save(self.excelpath)
        # 全局的行变量自增1
        self.rowIndex = self.rowIndex + 1
        return item
