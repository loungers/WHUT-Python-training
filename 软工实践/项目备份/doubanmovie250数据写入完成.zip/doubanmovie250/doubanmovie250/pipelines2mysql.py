# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter

# 导入模块
import pymysql


class Doubanmovie250Pipeline:
    def process_item(self, item, spider):
        # 设置一个全局连接变量
        connection = ''
        try:
            # 获取一个又效的数据库连接对象
            connection = pymysql.connect(host='localhost', port=3306, \
                                         user='root', password='dw123456', \
                                         db='crawl', charset='utf8')
            if connection:
                print('[MySQL]>> 正确获取数据库连接对象。')

            # 创建一个游标对象
            cursor = connection.cursor()
            print('[MYSQL]>> 正确获取游标对象.')

            # 设置插入数据的SQL语句模板
            rank = int(item['rank'][0])
            title = item['title'][0]
            rating_num = item['rating_num'][0]
            comment_num = item['comment_num'][0]
            info = item['info'][0]
            motto = item['motto'][0]
            sql = 'INSERT INTO movieinfo values(%d, \'%s\', \'%s\', \'%s\', \'%s\', \'%s\')' % (rank, title, rating_num, comment_num, info, motto)
            print('[MYSQL]>> %s' % sql)

            # 使用游标对象发送SQL语句并将服务器结果返回
            affectedRows = cursor.execute(sql)
            msg = '[MYSQL]>> 写入操作成功。' \
                if affectedRows > 0 else '[MYSQL]>> 写入操作失败。'
            print(msg)

            # 事务提交
            connection.commit()
            print('[MYSQL]>> 事务提交')
        except:
            # 事务回滚
            connection.rollback()
            print('[MYSQL]>> 事务回滚')
        finally:
            # 关闭数据库连接
            connection.close()
            print('[MYSQL]>> 数据库关闭连接')
        return item

# 数据库全部删除命令 truncate table movieinfo;
