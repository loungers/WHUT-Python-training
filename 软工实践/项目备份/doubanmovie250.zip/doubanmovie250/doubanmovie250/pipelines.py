# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter


class Doubanmovie250Pipeline:
    def process_item(self, item, spider):
        print('电影排名：{0}'.format(item['rank'][0]))
        print('电影名称：{0}'.format(item['title'][0]))
        print('电影评分：{0}'.format(item['rating_num'][0]))
        print('评论人数：{0}'.format(item['comment_num'][0]))
        print('主创：{0}'.format(item['info'][0]))
        print('电影格言：{0}'.format(item['motto'][0]))
        return item
