/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80021
 Source Host           : localhost:3306
 Source Schema         : crawl

 Target Server Type    : MySQL
 Target Server Version : 80021
 File Encoding         : 65001

 Date: 26/07/2020 20:00:02
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for movieinfo
-- ----------------------------
DROP TABLE IF EXISTS `movieinfo`;
CREATE TABLE `movieinfo` (
  `rank` int DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `rating_num` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `comment_num` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `motto` varchar(255) DEFAULT NULL,
  `pic_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of movieinfo
-- ----------------------------
BEGIN;
INSERT INTO `movieinfo` VALUES (1, '肖申克的救赎', '9.7', '2088503人评价', '导演: 弗兰克·德拉邦特 Frank Darabont   主演: 蒂姆·罗宾斯 Tim Robbins /...', '希望让人自由。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p480747492.jpg');
INSERT INTO `movieinfo` VALUES (2, '霸王别姬', '9.6', '1549015人评价', '导演: 陈凯歌 Kaige Chen   主演: 张国荣 Leslie Cheung / 张丰毅 Fengyi Zha...', '风华绝代。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2561716440.jpg');
INSERT INTO `movieinfo` VALUES (3, '阿甘正传', '9.5', '1577453人评价', '导演: 罗伯特·泽米吉斯 Robert Zemeckis   主演: 汤姆·汉克斯 Tom Hanks / ...', '一部美国近现代史。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2372307693.jpg');
INSERT INTO `movieinfo` VALUES (4, '这个杀手不太冷', '9.4', '1767656人评价', '导演: 吕克·贝松 Luc Besson   主演: 让·雷诺 Jean Reno / 娜塔莉·波特曼 ...', '怪蜀黍和小萝莉不得不说的故事。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p511118051.jpg');
INSERT INTO `movieinfo` VALUES (5, '泰坦尼克号', '9.4', '1531033人评价', '导演: 詹姆斯·卡梅隆 James Cameron   主演: 莱昂纳多·迪卡普里奥 Leonardo...', '失去的才是永恒的。 ', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p457760035.jpg');
INSERT INTO `movieinfo` VALUES (6, '美丽人生', '9.5', '987578人评价', '导演: 罗伯托·贝尼尼 Roberto Benigni   主演: 罗伯托·贝尼尼 Roberto Beni...', '最美的谎言。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2578474613.jpg');
INSERT INTO `movieinfo` VALUES (7, '千与千寻', '9.4', '1640417人评价', '导演: 宫崎骏 Hayao Miyazaki   主演: 柊瑠美 Rumi Hîragi / 入野自由 Miy...', '最好的宫崎骏，最好的久石让。 ', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2557573348.jpg');
INSERT INTO `movieinfo` VALUES (8, '辛德勒的名单', '9.5', '803343人评价', '导演: 史蒂文·斯皮尔伯格 Steven Spielberg   主演: 连姆·尼森 Liam Neeson...', '拯救一个人，就是拯救整个世界。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p492406163.jpg');
INSERT INTO `movieinfo` VALUES (9, '盗梦空间', '9.3', '1505755人评价', '导演: 克里斯托弗·诺兰 Christopher Nolan   主演: 莱昂纳多·迪卡普里奥 Le...', '诺兰给了我们一场无法盗取的梦。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p513344864.jpg');
INSERT INTO `movieinfo` VALUES (10, '忠犬八公的故事', '9.4', '1048132人评价', '导演: 莱塞·霍尔斯道姆 Lasse Hallström   主演: 理查·基尔 Richard Ger...', '永远都不能忘记你所爱的人。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p524964039.jpg');
INSERT INTO `movieinfo` VALUES (11, '海上钢琴师', '9.3', '1255994人评价', '导演: 朱塞佩·托纳多雷 Giuseppe Tornatore   主演: 蒂姆·罗斯 Tim Roth / ...', '每个人都要走一条自己坚定了的路，就算是粉身碎骨。 ', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2574551676.jpg');
INSERT INTO `movieinfo` VALUES (12, '楚门的世界', '9.3', '1128803人评价', '导演: 彼得·威尔 Peter Weir   主演: 金·凯瑞 Jim Carrey / 劳拉·琳妮 Lau...', '如果再也不能见到你，祝你早安，午安，晚安。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p479682972.jpg');
INSERT INTO `movieinfo` VALUES (13, '三傻大闹宝莱坞', '9.2', '1398251人评价', '导演: 拉库马·希拉尼 Rajkumar Hirani   主演: 阿米尔·汗 Aamir Khan / 卡...', '英俊版憨豆，高情商版谢耳朵。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p579729551.jpg');
INSERT INTO `movieinfo` VALUES (14, '机器人总动员', '9.3', '990657人评价', '导演: 安德鲁·斯坦顿 Andrew Stanton   主演: 本·贝尔特 Ben Burtt / 艾丽...', '小瓦力，大人生。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1461851991.jpg');
INSERT INTO `movieinfo` VALUES (15, '放牛班的春天', '9.3', '972607人评价', '导演: 克里斯托夫·巴拉蒂 Christophe Barratier   主演: 热拉尔·朱尼奥 Gé...', '天籁一般的童声，是最接近上帝的存在。 ', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1910824951.jpg');
INSERT INTO `movieinfo` VALUES (16, '星际穿越', '9.3', '1130297人评价', '导演: 克里斯托弗·诺兰 Christopher Nolan   主演: 马修·麦康纳 Matthew Mc...', '爱是一种力量，让我们超越时空感知它的存在。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614988097.jpg');
INSERT INTO `movieinfo` VALUES (17, '大话西游之大圣娶亲', '9.2', '1106961人评价', '导演: 刘镇伟 Jeffrey Lau   主演: 周星驰 Stephen Chow / 吴孟达 Man Tat Ng...', '一生所爱。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2455050536.jpg');
INSERT INTO `movieinfo` VALUES (18, '熔炉', '9.3', '681971人评价', '导演: 黄东赫 Dong-hyuk Hwang   主演: 孔侑 Yoo Gong / 郑有美 Yu-mi Jung /...', '我们一路奋战不是为了改变世界，而是为了不让世界改变我们。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1363250216.jpg');
INSERT INTO `movieinfo` VALUES (19, '疯狂动物城', '9.2', '1327972人评价', '导演: 拜伦·霍华德 Byron Howard / 瑞奇·摩尔 Rich Moore   主演: 金妮弗·...', '迪士尼给我们营造的乌托邦就是这样，永远善良勇敢，永远出乎意料。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2614500649.jpg');
INSERT INTO `movieinfo` VALUES (20, '无间道', '9.2', '903130人评价', '导演: 刘伟强 / 麦兆辉   主演: 刘德华 / 梁朝伟 / 黄秋生', '香港电影史上永不过时的杰作。', 'https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2564556863.jpg');
INSERT INTO `movieinfo` VALUES (21, '龙猫', '9.2', '934338人评价', '导演: 宫崎骏 Hayao Miyazaki   主演: 日高法子 Noriko Hidaka / 坂本千夏 Ch...', '人人心中都有个龙猫，童年就永远不会消失。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2540924496.jpg');
INSERT INTO `movieinfo` VALUES (22, '教父', '9.3', '682407人评价', '导演: 弗朗西斯·福特·科波拉 Francis Ford Coppola   主演: 马龙·白兰度 M...', '千万不要记恨你的对手，这样会让你失去理智。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p616779645.jpg');
INSERT INTO `movieinfo` VALUES (23, '当幸福来敲门', '9.1', '1122231人评价', '导演: 加布里尔·穆奇诺 Gabriele Muccino   主演: 威尔·史密斯 Will Smith ...', '平民励志片。 ', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2614359276.jpg');
INSERT INTO `movieinfo` VALUES (24, '怦然心动', '9.1', '1304241人评价', '导演: 罗伯·莱纳 Rob Reiner   主演: 玛德琳·卡罗尔 Madeline Carroll / 卡...', '真正的幸福是来自内心深处。', 'https://img1.doubanio.com/view/photo/s_ratio_poster/public/p501177648.jpg');
INSERT INTO `movieinfo` VALUES (25, '触不可及', '9.2', '728909人评价', '导演: 奥利维·那卡什 Olivier Nakache / 艾力克·托兰达 Eric Toledano   主...', '满满温情的高雅喜剧。', 'https://img9.doubanio.com/view/photo/s_ratio_poster/public/p1454261925.jpg');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
